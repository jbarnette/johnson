## -*- Ruby -*-
## XML::DOM::DOMBuilderFilter
## 2001 by yoshidam
##

module XML
  module DOM
    module DOMBuilderFilter
      def endElement(element); end
    end
  end
end
