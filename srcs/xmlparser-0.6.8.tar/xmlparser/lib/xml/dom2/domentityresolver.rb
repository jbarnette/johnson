## -*- Ruby -*-
## XML::DOM::DOMEntityResolver
## 2001 by yoshidam
##

module XML
  module DOM
    module DOMEntityResolver
      ## DOMInputSource resolveEntity(publicId, systemId)
      def resolveEntity(publicId, systemId); end
    end
  end
end
