## -*- Ruby -*-
## XML::Parser (alias of XMLParser)
## 1998 by yoshidam

require 'xmlparser.so'

#module XML
#  Parser = XMLParser
#  class Parser
#    Error = XMLParserError
#  end
#  Encoding = XMLEncoding
#end
