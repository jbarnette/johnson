## -*- Ruby -*-
## Tree builder class for Japanese encoding
## 1998 by yoshidam

require 'xml/dom/builder-ja'

module XML
  JapaneseTreeBuilder = DOM::JapaneseBuilder
end
