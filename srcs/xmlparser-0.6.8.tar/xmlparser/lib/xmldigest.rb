require 'xml/dom/digest'
