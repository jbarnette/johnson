## -*- Ruby -*-
## Sample XMLEncoding class for Japanese (EUC-JP, Shift_JIS)
## 1998 by yoshidam
##
## Usage:
##    require 'xml/encoding-ja'
##    include XMLEncoding_ja

require 'xml/encoding-ja'

XMLEncoding_ja = XML::Encoding_ja
